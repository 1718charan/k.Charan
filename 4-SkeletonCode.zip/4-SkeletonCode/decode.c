
#include<stdio.h>
#include<string.h>
#include "types.h"
#include "decode.h"

Status read_and_validate_decode_args(char *argv[],DecodeInfo *decInfo)
{
    if(strcmp(strstr(argv[2],"."),".bmp")==0)
    {
	decInfo -> src_image_fname = argv[2];
    }
    else
    {
	return e_failure;
    }
    if(argv[3]!=NULL)
    {
	decInfo ->output_fname = argv[3];
    }
    else
    {
	decInfo->output_fname = "fileresult";
    }
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    printf("enter magic string\n");
    scanf("%s",decInfo->magic_string);
    decInfo->magic_len=strlen(decInfo->magic_string);
    if(open_files_dec(decInfo)!=e_success)
    {
	printf("files open Failed  ..\n");
 
        return e_failure;
    }
    if(decode_magic_string_len (decInfo->magic_len,decInfo)!= e_success)
    {
	printf("Magic len not matched..\n");
	return e_failure;
    }
    if(decode_magic_string(decInfo->magic_string,decInfo)!= e_success)
    {
	printf("magic string doesn't match..\n");
	return e_failure;
    }	
}

Status open_files_dec(DecodeInfo *decInfo)
{
    decInfo ->fptr_src_image=fopen(decInfo -> src_image_fname,"r");
    if(decInfo ->fptr_src_image == NULL)
    {
	perror("fopen");
	fprintf(stderr,"ERROR : Unable to open file %s\n",decInfo ->src_image_fname);
	return e_failure;
    }
    else
    {
	return e_success;
    }
}
char byte_to_lsb(DecodeInfo *decInfo)
{
    char ch=0;
    char buf[8];
    int index=0;
    fread(buf, 8, 1,decInfo->fptr_src_image);
    for(int i=7;i>=0;i--)
    {
	ch = (((buf[index])&1)<<i) | ch;
	index++;
    }
    return ch;
}

int iiint_to_lsb(DecodeInfo *decInfo)
{
    int ch=0;
    char buf[32];
    int index=0;
    fread(buf,32,1,decInfo ->fptr_src_image);
    printf("%ld\n",ftell(decInfo->fptr_src_image ));
    for(int i=31;i>=0;i--)
    {
	ch = (((buf[index])&1)<<i) | ch;
	index++;
    }
    printf("%d\n",ch);
    return ch;
}
Status decode_magic_string_len (int data, DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_src_image, 54, SEEK_SET);
    if(data == int_to_lsb(decInfo))
    {
	printf("Magic len matched ..\n");
	return e_success;
    }
}

Status decode_magic_string(const char *magic, DecodeInfo *decInfo)
{
    for(int i = 0; i< decInfo->magic_len;i++)
    {
	if(magic[i] != byte_to_lsb(decInfo))
	    return e_failure;
    }
    printf("Magic string matched ..\n");
    return e_success;
}
Status decode_secret_file_size_extn(long file_size, DecodeInfo *decInfo)
{
    decInfo -> size_secret_file_extn = int_to_lsb(decInfo); 
}

Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    decInfo->secret_file_extn[decInfo ->size_secret_file_extn];
    for(int i=7 ;i>=0;i--)
    {
        decInfo->secret_file_extn[i]=byte_to_lsb(decInfo);
	strcat(decInfo->output_fname,decInfo->secret_file_extn);
	decInfo->output_image=fopen(decInfo->output_fname,"w");
    }
}

Status decode_secret_file_size(DecodeInfo *decInfo)
{
   decInfo->size_secret_file=int_to_lsb(decInfo);

}
 
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char ch;
    for ( int i=0;i<decInfo->size_secret_file;i++)
    {
       ch =byte_to_lsb(decInfo);
       fwrite(&ch,1,1,decInfo->output_image);       
    }
}


