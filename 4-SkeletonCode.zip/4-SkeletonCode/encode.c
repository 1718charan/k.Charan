#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "common.h"

/* Function Definitions */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if(strcmp(strstr(argv[2],"."),".bmp")==0)
    {
	encInfo->src_image_fname = argv[2];
    }
    else
    {
	return e_failure;
    }
    if((strcmp(strstr(argv[3],"."),".txt")==0) || (strcmp(strstr(argv[3],"."),".sh")==0) || (strcmp(strstr(argv[3],"."),".c")==0))
    {
	encInfo->secret_fname = argv[3];
    }
    else
    {
	return e_failure;
    }
    if(argv[4]!=NULL)
    {
	if (strcmp(strstr(argv[4],"."),".bmp")==0)
	{
	    encInfo->stego_image_fname=argv[4];
	}
	else
	{
	    return e_failure;
	}
    }

    /* argv is .bmp or not
       .bmp => encInfo -> src_image_fname = argv[2]
       not => return e_failure */
    /*
       argv[3] is .txt or .c or .sh
       yes =>encInfo ->secret_fname
       not =>return e_failure */
    /*
       argv[4]  is passed or not
       passed -> check argv[4] is .bmp or not
                  yes => encInfo  -> stego_image_fname
		  not => return e_failure
		  
	not passed => encInfo -> stego_image_fname = "default.bmp" */
    else
    {
	encInfo -> stego_image_fname = "default.bmp";
    }
    return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    if(open_files(encInfo) == e_success)
    {
	// read magic string

	printf("file open Successfully Done...\n");
	printf("Enter the magic string:\n");
	
	scanf("%s",encInfo -> magic_string);
	
	if(check_capacity(encInfo) == e_success)
	{
	    printf("Capacity check is successfull..has enough capacity\n");
	    if(copy_bmp_header(encInfo ->fptr_src_image,encInfo ->fptr_stego_image)==e_success)
	    {
		printf("Copied header successfully\n");

		if(encode_magic_string_len(encInfo ->magic_len, encInfo)==e_success)
		{
		    printf("Magic string extension stored successfully\n");
		    if(encode_magic_string(encInfo ->magic_string, encInfo)==e_success)
		    {
			printf("Magic string encoding success\n");

			if(encode_secret_file_size(encInfo -> size_secret_file,encInfo)==e_success)
			{
			    printf("Secret file extn size success\n");
			    if(encode_secret_file_extn(encInfo)==e_success)
			    {
				printf("Secret file extension is successfull\n");
		                if(encode_secret_file_size(encInfo ->size_secret_file, encInfo) == e_success)
				{
				    printf("secret file size is successfull\n");
				   
				    if(encode_secret_file_data(encInfo)==e_success)
				    {
					printf("secret file data is successfull\n");
				    }
				    if(copy_remaining_img_data(encInfo ->fptr_src_image,encInfo ->fptr_stego_image)==e_success)
				    {
					printf("copied remaining data is successfull\n");
					return e_success;
				    }
				    else
				    {
					printf("copied remaining data is failure\n");
					return e_failure;
				    }
				}
				else
				{
				    printf("secret file data is failed\n");
				}
			    }
			    else
			    {
				printf("secret file is failure\n");
				return e_failure;
			    }
			}
			else
			{
			    printf("secret file extn was failure\n");
			    return e_failure;
			}
		    }
		    else
		    {
			printf("secret file extn size was failure\n");
			return e_failure;
		    }
		}
		else
		{
		    printf("Magic string encoding failure\n");
		    return e_failure;
		}
	    }
	    else
	    {
		printf("copied header file failed\n");
		return e_failure;
	    }
	}
	else
	{
	    printf("Check capacity was failed\n");
	}
    }
}

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo ->fptr_src_image);

    // find the length of magic_string
    encInfo -> magic_len = strlen(encInfo ->magic_string);
    // find the secret file extn size
    encInfo ->size_secret_file_extn = strlen(strstr(encInfo ->secret_fname,".txt"));

    //find secret file size

    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);

    // .bmp should > headerfile(54) + encoding 6 steps
    if(encInfo ->image_capacity > 54 + 32 +(encInfo -> magic_len * 8) + 32 +(encInfo -> size_secret_file_extn * 8) + 32 + (encInfo -> size_secret_file * 8))
    {
	return e_success;
    }
    else
    {
	return e_failure;
    }

}

uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);
    ftell(fptr);
}

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
Status copy_bmp_header (FILE *fsrc, FILE *fdes)
{
    char buf[54];
    rewind(fsrc);
    fread(buf, 54, 1, fsrc);
    fwrite(buf, 54, 1, fdes);
    return e_success;
}
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    int index=0;
    for(int i=7;i>=0;i--)
    {
	if(data & (1<<i))
	{
	    image_buffer[index]=image_buffer[index] | 1;
	}
	else
	{
	    image_buffer[index]=image_buffer[index] & ~1;
	}
	index++;
    }
}
Status encode_int_to_lsb(int data,char *image_buffer)
{
    int index=0;
    for(int i=31;i>=0;i--)
    {
	if(data &(1<<i))
	{
	    image_buffer[index] = image_buffer[index] | 1;
	}
	else
	{
	    image_buffer[index] = image_buffer[index] & ~1;
	}
	index++;
    }
}

Status encode_magic_string_len(int data, EncodeInfo *encInfo)
{
    char image_buffer[32];
    fread(image_buffer,32,1,encInfo ->fptr_src_image);
    encode_int_to_lsb(data, image_buffer);
    fwrite(image_buffer,32,1,encInfo -> fptr_stego_image);
    return e_success;
}

Status encode_magic_string(const char *magic_string,EncodeInfo *encInfo)
{
    for(int i=0;i<strlen(magic_string);i++)
    {
	char buf[8];
	fread(buf,8,1,encInfo -> fptr_src_image);
	encode_byte_to_lsb(magic_string[i],buf);
	fwrite(buf,8,1,encInfo-> fptr_stego_image);
    }
    printf("%ld %ld\n",ftell(encInfo -> fptr_src_image),ftell(encInfo ->fptr_stego_image));
    return e_success;
}

Status encode_secret_file_extn_size(int data, EncodeInfo *encInfo)
{
    char buf[32];
    fread(buf,32,1,encInfo ->fptr_src_image);
    encode_int_to_lsb(data, buf);
    fwrite(buf,32,1,encInfo ->fptr_stego_image);
}
Status encode_secret_file_extn(EncodeInfo *encInfo)
{
    char secret[10];
    char buf[8];
    strcpy(secret,strstr(encInfo -> secret_fname,"."));
    for(int i=0;i<strlen(secret);i++)
    {
	char buf[8];
	fread(buf,8, 1,encInfo->fptr_src_image);
	encode_byte_to_lsb(secret[i], buf);
	fwrite(buf, 8, 1, encInfo->fptr_stego_image);
    }
    return e_success;
}

Status encode_secret_file_size(long secret_file_len, EncodeInfo *encInfo)
{
    char buf[32];
    fread(buf,32,1,encInfo ->fptr_src_image);
    encode_int_to_lsb(secret_file_len, buf);
    fwrite(buf,32,1,encInfo ->fptr_stego_image);
    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char buf[8];
    char secret[encInfo ->size_secret_file];
    rewind(encInfo -> fptr_secret);
    fread(secret,1 ,encInfo -> size_secret_file, encInfo -> fptr_secret);
    for(int i=0;i < encInfo -> size_secret_file;i++)
    {
	fread(buf,1,8, encInfo ->fptr_src_image);
	encode_byte_to_lsb(secret[i],buf);
	fwrite(buf,8,1,encInfo ->fptr_stego_image);
    }
    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while(fread (&ch,1,1,fptr_src) > 0)
    {
	fwrite(&ch,1,1,fptr_dest);
    }
    return e_success;
}


