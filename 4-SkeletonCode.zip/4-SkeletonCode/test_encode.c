#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

int main(int argc, char *argv[])
{
   int res=check_operation_type(argv);
   
   EncodeInfo encInfo;  //structure var
   DecodeInfo decInfo;
   
   if(res==e_encode)
   {
       printf("selected encoding\n");
       if(read_and_validate_encode_args(argv,&encInfo)==e_success)
       {
	   printf("validation successful\n");
           if(do_encoding(&encInfo)==e_success)
	       printf("encoding done\n");
           else
	       printf("encoding failed\n");
       }
   }
   else if(res==e_decode)
   {
       printf("selected decoding\n");
       if(read_and_validate_decode_args(argv, &decInfo)==e_success)

       {
	   printf("Validation successfull\n");
		   if(do_decoding(&decInfo)==e_success)
		       printf("decoding Done\n");
		   else
		       printf("decoding failed\n");
       }
   }
   else
   {
       printf("Error: for encoding: ./a.out -e beautiful.bmp secret.txt\nfor decoding: ./a.out -d output.bmp");
   }
}
OperationType check_operation_type(char * argv[])
{
    if(strcmp(argv[1],"-e")==0)     //check argv is -e or not
    {
	return e_encode;
    }
    else if(strcmp(argv[1],"-d")==0)   //check argv is -d or not
    {
	return e_decode;
    }
    else
    {
	return e_unsupported;
    }
}
